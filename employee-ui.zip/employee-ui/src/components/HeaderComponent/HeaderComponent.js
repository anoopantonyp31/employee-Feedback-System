import React, { Component } from 'react';
import axios from 'axios';
import './HeaderComponent.css';
import {withRouter} from "react-router";
import Navbar from 'react-bootstrap/Navbar';
import {Button, Nav} from 'react-bootstrap';
import {NavDropdown} from 'react-bootstrap';
import {Link} from 'react-router-dom';
class HeaderComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
           emp_name:""
        }
    } 

    componentDidMount(){
      axios.post('http://localhost:9000/listEmployeeSelected', {           
            emp_id:this.props.location.empID         

          })
          .then((response)=> {           
            if(response.data.status=="success"){    
              
              this.setState({
                emp_name:  response.data.dataValue[0].emp_name
              })
             
            }
          })
          .catch(function (error) {
            console.log(error);
          });
    }

   

    render() {
        return (
            <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
            <Navbar.Brand href="#home">Welcome :{this.state.emp_name} -- {this.props.location.empID} ,({this.props.location.empRoll})</Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav">
              <Nav className="mr-auto">
                
              </Nav>
              <Nav>
                
                <Link className="nav-link" to="/">
                  Log Out
                </Link>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
            );

    }




}

 

export default withRouter(HeaderComponent);