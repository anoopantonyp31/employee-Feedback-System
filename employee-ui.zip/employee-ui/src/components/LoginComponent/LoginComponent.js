import React, { Component } from 'react';
import axios from 'axios';
import './LoginComponent.css';
import {withRouter} from "react-router";

class LoginComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            userName:"",
            password:""
        }
    } 

    userNameOnChange=(e)=>{
        this.setState({
            userName: e.target.value
        })
    }

    passwordOnChange=(e)=>{
        this.setState({
            password: e.target.value
        })
    }

    signInClick =(e)=>{        
        axios.post('http://localhost:9000/loginValidation', {
            userName: this.state.userName,
            password: this.state.password
          })
          .then((response)=> {           
            if(response.data.status=="success"){
                console.log(response.data.dataValue[0]);
                let emp_id = response.data.dataValue[0].emp_id;
                let roll = response.data.dataValue[0].emp_roll;
                if(roll=="Admin"){
                    this.props.history.push({pathname:'/adminPage',empID:emp_id,empRoll:roll});
                }
                else{
                    this.props.history.push({pathname:'/employeePage',empID:emp_id,empRoll:roll});
                }
               
                    //this.state();
            }
            else{
                alert("Invalid Details Provided");
            }
          })
          .catch(function (error) {
            console.log(error);
          });

    }

    render() {
        return (
            <div className="topWrapper">           
                <div className="mainFromWrapper">
                    <h3>Log in</h3>
                    <div className="form-group">
                        <label className="login-label">Username</label>
                        <input type="text" className="form-control" placeholder="Enter Username" onChange={this.userNameOnChange} />
                    </div>
                    <div className="form-group">
                        <label className="login-label">Password</label>
                        <input type="password" className="form-control" placeholder="Enter password" onChange={this.passwordOnChange}/>
                    </div>
                    <div className="form-group">
                        <div className="custom-control custom-checkbox">
                            <input type="checkbox" className="custom-control-input" id="customCheck1" />
                            <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                        </div>
                    </div>
                    <button onClick={this.signInClick} className="btn btn-dark btn-lg btn-block">Sign in</button>
                    <p className="forgot-password text-right">
                        Forgot <a href="#">password?</a>
                    </p>
                </div>
            </div>
            );

    }




}

 

export default withRouter(LoginComponent);